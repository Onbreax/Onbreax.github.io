@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 gmail-local.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python 3.9 ou plus recent est necessaire pour ce lanceur.
  ) else (
    python gmail-local.py
  )
)
pause
